import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BMIApplication extends JFrame {
    
    //JLabel
    JLabel heightLabel = new JLabel();
    JLabel weightLabel = new JLabel();
    JLabel inches = new JLabel();
    JLabel pounds = new JLabel();
    
    //JTextField
    JTextField heightText = new JTextField();
    JTextField weightText = new JTextField();
    
    //JButton
    JButton bmiButton = new JButton();
    JButton clearButton = new JButton();
    JButton exitButton = new JButton();
    
    public BMIApplication() {
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        setTitle("BMI Application");
        
        heightLabel.setText("HEIGHT:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(heightLabel, gridConstraints);
        
        heightText.setText("                  ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        getContentPane().add(heightText, gridConstraints);
        
        inches.setText("inches");
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 0;
        getContentPane().add(inches, gridConstraints);
        
        weightLabel.setText("WEIGHT:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(weightLabel, gridConstraints);
        
        weightText.setText("                  ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        getContentPane().add(weightText, gridConstraints);
        
        pounds.setText("pounds");
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 1;
        getContentPane().add(pounds, gridConstraints);
        
        bmiButton.setText("Compute BMI");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(bmiButton, gridConstraints);
        
        clearButton.setText("Clear");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 2;
        getContentPane().add(clearButton, gridConstraints);
        
        exitButton.setText("Exit");
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 2;
        getContentPane().add(exitButton, gridConstraints);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitForm(e);
            }
        });
        
        bmiButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bmiButtonActionPerformed(e);
            }
        });
        
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearButtonActionPerformed(e);
            }
        });
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButtonActionPerformed(e);
            }
        });
        
        pack();
        
    }
    
    private void exitForm(WindowEvent e) {
        JFrame myFrame = new JFrame();
        JOptionPane.showMessageDialog(myFrame, "Exiting Form");
    }
    
    private void bmiButtonActionPerformed(ActionEvent e) {
        JFrame myFrame = new JFrame();
        
        Double height = Double.parseDouble(heightText.getText());
        Double weight = Double.parseDouble(weightText.getText());
        Double bmi = weight / Math.pow(height, 2) * 703;
        
        JOptionPane.showMessageDialog(myFrame, "Your BMI is " + bmi);
    }
    
    private void clearButtonActionPerformed(ActionEvent e) {
        JFrame myFrame = new JFrame();
        JOptionPane.showMessageDialog(myFrame, "Clearing Computation");
        System.exit(0);
    }
    
    private void exitButtonActionPerformed(ActionEvent e) {
        JFrame myFrame = new JFrame();
        JOptionPane.showMessageDialog(myFrame, "Exiting");
        System.exit(0);
    }
    
    public static void main(String[] args) {
        new BMIApplication().show();
    }
}